// DigiBlast — All agents in one serverless function
// Deploy to Vercel: zero config, free tier, works instantly

const CLAUDE_KEY = process.env.CLAUDE_API_KEY;
const KIE_KEY    = process.env.KIE_API_KEY;

async function callClaude(system, user) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': CLAUDE_KEY,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1500,
      system,
      messages: [{ role: 'user', content: user }]
    })
  });
  const d = await res.json();
  if (!res.ok) throw new Error(d.error?.message || 'Claude API error');
  return d.content?.[0]?.text || '';
}

function parseJSON(text, fallback) {
  try {
    return JSON.parse(text.replace(/```json|```/g, '').trim());
  } catch {
    return fallback;
  }
}

async function submitKieImage(prompt) {
  if (!KIE_KEY) return null;
  try {
    const res = await fetch('https://api.kie.ai/api/v1/flux/kontext/generate', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${KIE_KEY}`,
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        prompt,
        model: 'flux-kontext-pro',
        aspectRatio: '1:1',
        outputFormat: 'jpeg'
      })
    });
    const d = await res.json();
    return d.data?.taskId || d.taskId || null;
  } catch {
    return null;
  }
}

async function pollKieImage(taskId) {
  for (let i = 0; i < 20; i++) {
    await new Promise(r => setTimeout(r, 4000));
    try {
      const res = await fetch(
        `https://api.kie.ai/api/v1/flux/kontext/record-info?taskId=${taskId}`,
        { headers: { 'Authorization': `Bearer ${KIE_KEY}` } }
      );
      const d = await res.json();
      const info = d.data?.info || d.data || d.info || d;
      const status = (info?.status || '').toUpperCase();
      if (status === 'COMPLETED' || status === 'SUCCESS') {
        return info?.resultImageUrl || info?.resultUrl || null;
      }
      if (status === 'FAILED' || status === 'ERROR') return null;
    } catch {
      // keep polling
    }
  }
  return null;
}

export default async function handler(req, res) {
  // CORS — allow all origins
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  if (!CLAUDE_KEY) {
    return res.status(500).json({ error: 'CLAUDE_API_KEY not set in environment variables' });
  }

  const {
    business_name = 'Your Business',
    business_type = 'products',
    campaign_goal = 'Promote our business',
    language = 'both',
    platforms = ['facebook','instagram','tiktok','whatsapp','google']
  } = req.body || {};

  const langNote = language === 'bn'
    ? 'Write ONLY in Bengali (Bangla).'
    : language === 'en'
    ? 'Write ONLY in English.'
    : 'Write in BOTH Bengali and English. Bengali first, then "---", then English.';

  try {
    // ── AGENT 1: BRAND INTEL ─────────────────────────────
    const brandRaw = await callClaude(
      'Brand Intelligence Agent. Return ONLY valid JSON, no markdown: {"tone":"...","audience":"...","usp":"..."}',
      `Business: ${business_name}\nType: ${business_type}\nGoal: ${campaign_goal}`
    );
    const brand = parseJSON(brandRaw, {
      tone: 'warm, community-focused, trustworthy',
      audience: 'local families and community members',
      usp: 'quality and reliability'
    });

    // ── AGENT 2: STRATEGY ────────────────────────────────
    const stratRaw = await callClaude(
      'Strategy Agent. Return ONLY valid JSON, no markdown: {"campaign_name":"...","hashtags":["7 tags"],"tone":"...","key_message":"...","best_times":{"facebook":"Friday 12pm","instagram":"Saturday 9am","tiktok":"Friday 6pm","whatsapp":"Thursday 7pm","google":"Monday 9am"}}',
      `Business: ${business_name} (${business_type})\nGoal: ${campaign_goal}\nTone: ${brand.tone}\nAudience: ${brand.audience}\nLanguage: ${language}`
    );
    const strategy = parseJSON(stratRaw, {
      campaign_name: `${business_name} Campaign`,
      hashtags: [`#${business_name.replace(/\s+/g,'')}`, '#Bangladesh', '#LocalBusiness', '#SME', '#Dhaka', `#${business_type.replace(/\s+/g,'')}`, '#DigiBlast'],
      tone: brand.tone,
      key_message: campaign_goal,
      best_times: { facebook:'Friday 12pm', instagram:'Saturday 9am', tiktok:'Friday 6pm', whatsapp:'Thursday 7pm', google:'Monday 9am' }
    });

    // ── AGENT 3: COPYWRITER ──────────────────────────────
    const copyRaw = await callClaude(
      `Social media Copywriter for ${business_name}. ${langNote} Write warm human community copy, NOT corporate. Return ONLY valid JSON, no markdown: {"facebook":"warm 3-4 sentences+CTA","instagram":"2-3 punchy lines+emojis","tiktok":"hook+3 bullets+CTA","whatsapp":"friendly personal message","google":"professional 2-3 sentences+CTA","image_prompt":"DALL-E prompt 60 words English only","video_script":"5-second Reels script 3 scenes with text overlays"}`,
      `Business: ${business_name} (${business_type})\nGoal: ${campaign_goal}\nTone: ${strategy.tone}\nKey message: ${strategy.key_message}`
    );
    const copy = parseJSON(copyRaw, {
      facebook: `Great news from ${business_name}! We now offer ${campaign_goal}. Trusted quality, delivered with care. Order now!`,
      instagram: `Fresh from ${business_name}! 🚀\n${campaign_goal} ⚡\nOrder now ✅`,
      tiktok: `Hook: ${business_name} has big news!\n• ${campaign_goal}\n• Trusted quality\n• Order today`,
      whatsapp: `Hello! Great news from ${business_name} 🌟\n${campaign_goal}\nContact us to order!`,
      google: `${business_name} now offers ${campaign_goal}. Quality service for your community. Contact us today!`,
      image_prompt: `Professional commercial photography for ${business_name}, a ${business_type} business. Warm natural lighting, vibrant colors, social media ready, high quality photorealistic.`,
      video_script: `[Scene 1 0-2s] Show: ${business_type} close-up | Text: ${business_name}\n[Scene 2 2-4s] Show: ${campaign_goal} | Text: Order Now!\n[Scene 3 4-5s] Show: Happy customer | Text: Link in Bio 👇`
    });

    const hashtagStr = (strategy.hashtags || []).join(' ');

    // ── AGENT 4: IMAGE (Kie.ai, async) ───────────────────
    let imageUrl = null;
    if (KIE_KEY && copy.image_prompt) {
      const taskId = await submitKieImage(copy.image_prompt);
      if (taskId) imageUrl = await pollKieImage(taskId);
    }

    // ── FINAL RESPONSE ───────────────────────────────────
    return res.status(200).json({
      success: true,
      business_name,
      campaign_name: strategy.campaign_name,
      hashtags: strategy.hashtags || [],
      hashtag_string: hashtagStr,
      best_times: strategy.best_times || {},
      content: {
        facebook:  (copy.facebook  || '') + '\n\n' + hashtagStr,
        instagram: (copy.instagram || '') + '\n\n' + hashtagStr,
        tiktok:    (copy.tiktok    || '') + '\n\n' + hashtagStr,
        whatsapp:  copy.whatsapp || '',
        google:    copy.google   || ''
      },
      image_url:    imageUrl,
      image_prompt: copy.image_prompt || '',
      video_script: copy.video_script || '',
      language
    });

  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
